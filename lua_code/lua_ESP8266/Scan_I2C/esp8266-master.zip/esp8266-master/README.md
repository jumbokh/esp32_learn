# esp8266
esp8266 stuff

quick and dirty hack 

get temps and humidity from htu21d, show it on ssd1306 and send data to webserver

custom firware from http://frightanic.com/nodemcu-custom-build/

modules enabled : 
* node
* file
* gpio
* wifi
* net
* i2c
* tmr
* uart
* bit
* u8g

fonts for u8g :
* font_6x10
* font_fub25
* font_chikita


![working project](https://raw.github.com/docice/esp8266/master/img/esp8266_ssd1306_htu21d.JPG)
